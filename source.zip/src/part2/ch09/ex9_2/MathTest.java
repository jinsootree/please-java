package part2.ch09.ex9_2;

import java.lang.Math;

public class MathTest {
    public static void main(String[] args) {
        System.out.printf("수학의 파이(원주율) 값: %f\n", Math.PI);
        System.out.printf("임의 난수 값: %f\n", Math.random());
        System.out.printf("9.81의 내림값: %f\n", Math.floor(9.81));
        System.out.printf("4의 제곱근: %f\n", Math.sqrt(4));
        System.out.printf("2의 3승: %f\n", Math.pow(2, 3));
    }
}