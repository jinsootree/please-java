package part2.ch12.ex12_4;

import java.util.ArrayList;

public class UncheckedExceptionTest {
    public static void main(String[] args) {
        ArrayList<String> names = null;
        names.add("Park");
    }
}