package part1.ch05.ex5_1;

public class Ex5_1 {
    public static void main(String[] args) {
        int n = 1;
        while (n < 4) {
            System.out.println(n);
            n++; // n = n + 1;
        }
        System.out.println("END");
    }
}
