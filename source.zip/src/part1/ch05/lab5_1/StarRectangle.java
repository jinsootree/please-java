package part1.ch05.lab5_1;

public class StarRectangle {
    public static void main(String[] args) {
        for (int row = 0; row < 3; row++) {
            for (int i = 0; i < 7; i++) {
                System.out.printf("* ");
            }
            System.out.println();
        }
    }
}
