package part1.ch05.ex5_5;

public class Ex5_5 {
    public static void main(String[] args) {
        int sum = 0;
        for (int i = 1; i <= 10; i++) {
            sum += i; // sum = sum + i;
        }
        System.out.printf("총합: %d", sum);
    }
}
