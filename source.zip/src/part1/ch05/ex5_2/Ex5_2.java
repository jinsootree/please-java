package part1.ch05.ex5_2;

public class Ex5_2 {
    public static void main(String[] args) {
        int n = 10;
        while (n > 0) {
            System.out.printf("%d ", n);
            n--; // n = n - 1;
        }
    }
}
