package part1.ch05.ex5_4;

public class Ex5_4 {
    public static void main(String[] args) {
        for (int i = 1; i <= 9; i++) {
            System.out.printf("3 x %d = %d\n", i, 3 * i);
        }
    }
}
