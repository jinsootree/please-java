package part1.ch01.ex1_2;

/*
 * 헬로 월드! 문자열 출력 프로그램
 * 파일명: Hello.java
 */

// 1. 클래스 작성
public class Hello {
    // 2. 메인 메소드 추가
    public static void main(String[] args) {
        // 3. 문자열 출력
        System.out.println("헬로 월드!");
    }
}
