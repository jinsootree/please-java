package part1.ch01.lab1_1;

/*
 * 자기 소개하기, 문자열 출력 프로그램
 * 파일명: Greetings.java
 */

// 1. 클래스 작성
public class Greetings {
    // 2. 메인 메소드 추가
    public static void main(String[] args) {
        // 3. 문자열 출력
        System.out.println("안녕, 반가워");
        System.out.println("나는 냥이라고해");
        System.out.println("잘 부탁할게!");
    }
}
