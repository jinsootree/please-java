package part1.ch06.ex6_1;

public class Ex6_1 {
    public static void main(String[] args) {
        String[] names = {"Sam", "Kate", "John", "Jenny"}; // 배열 생성

        System.out.println(names[0]); // "Sam" 출력
        System.out.println(names[1]); // "Kate" 출력
        System.out.println(names[2]); // "John" 출력
        System.out.println(names[3]); // "Jenny" 출력
    }
}
