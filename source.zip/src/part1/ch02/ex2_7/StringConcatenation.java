package part1.ch02.ex2_7;

public class StringConcatenation {
    public static void main(String[] args) {
        int month = 8;
        int day = 23;
        int n = 1;
        double weight = 5.4;

        System.out.println("-------------------------");
        System.out.println("고양이의 " + month + "월 " + day + "일 다이어트 일지");
        System.out.println("-------------------------");
        System.out.println("식사 횟수: " + n + "회");
        System.out.println("몸무게: " + weight + "kg");
    }
}
