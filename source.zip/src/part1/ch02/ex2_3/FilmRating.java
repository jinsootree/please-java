package part1.ch02.ex2_3;

public class FilmRating {
    public static void main(String[] args) {
        double rating;
        rating = 9.82;

        System.out.println("바람과 함께 사라지다 평점:");
        System.out.println(rating);
    }
}
