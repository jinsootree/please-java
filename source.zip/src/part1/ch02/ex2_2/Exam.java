package part1.ch02.ex2_2;

public class Exam {
    public static void main(String[] args) {
        int midScore;    // 중간 점수
        int finalScore;  // 기말 점수

        midScore = 68;
        finalScore = 88;

        System.out.println("학기 전 홍팍이의 중간 점수:");
        System.out.println(midScore);
        System.out.println("학기 전 홍팍이의 기말 점수:");
        System.out.println(finalScore);
    }
}
