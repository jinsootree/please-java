package part1.ch02.ex2_11;

public class DownCasting {
    public static void main(String[] args) {
        double tall = 176.6;
        double weight = 74.34;
        System.out.printf("신장: %dcm\n", tall);
        System.out.printf("체중: %dkg\n", weight);
    }
}
