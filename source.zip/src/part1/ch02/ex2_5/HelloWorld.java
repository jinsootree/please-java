package part1.ch02.ex2_5;

public class HelloWorld {
    public static void main(String[] args) {
        String message = "헬로 월드!";
        System.out.println(message);

        message = "웰컴 투 헬!";
        System.out.println(message);
    }
}