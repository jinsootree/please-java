package part1.ch02.ex2_1;

public class Greetings2 {
    public static void main(String[] args) {
        String name;
        name = "김한빛";

        System.out.println("안녕하세요~ 반갑습니다! 제 이름은,");
        System.out.println(name);
        System.out.println("입니다. 잘 부탁드립니다~");
    }
}
