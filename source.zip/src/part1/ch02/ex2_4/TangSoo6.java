package part1.ch02.ex2_4;

public class TangSoo6 {
    public static void main(String[] args) {
        boolean isBoomuk;
        isBoomuk = true;

        System.out.println("당신은 부먹파입니까?");
        System.out.println(isBoomuk);
    }
}
