package part1.ch02.ex2_9;

public class Arithmetic {
    public static void main(String[] args) {
        int x = 7 / 2;
        double y = 7 * 2.0;
        System.out.printf("x = %d, y = %f", x, y);
    }
}
